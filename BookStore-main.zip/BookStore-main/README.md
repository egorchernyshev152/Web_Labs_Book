# BookStore
CRUD is an application for ASP.NET Core, React (Next.js), EF Core, Postgresql, Docker, Clean architecture
